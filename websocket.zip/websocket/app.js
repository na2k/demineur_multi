
function startApp() {

  var btn = document.getElementById("get_server_connection");


  function connectToSocketServer(e) {
    e.preventDefault();
    var socket = io('http://localhost:3030'); // envoi un message vers server.js

      socket.on('user-want-play', function (data) { // on attend le message émis par server.js
        console.log("data from server");
        console.log(data);
        socket.emit('add-me-to-room', { my: 'data' }); // on peut continuer à communiquer
        socket.emit('i-have-played', { id: "1" }); // on peut continuer à communiquer
      });
  }

  btn.onclick = connectToSocketServer;

}

window.onload = startApp;
