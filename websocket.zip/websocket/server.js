/*jshint esversion : 6 */
var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
// var cors = require('cors');

// app.use(cors({ origin: '*' }));
io.origins(['*:*']);

app.get('/', function(req, res){
  res.send("hello from node");
});

const users = [];
const rooms = [
  {
    name: "room n",
    users: []
  },
];

io.on('connection', function(socket){
  console.log('a user connected');
  // récupérer ici les données de user ...
  /// requete sql ... et éventuellement convertir en json ...
  io.emit('user-want-play', {name: "toto"});

});

http.listen(3030, function(){
  console.log('listening on *:3000');
});
